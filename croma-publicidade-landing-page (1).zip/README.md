# Croma Publicidade e Propaganda — Landing Page Oficial

Landing page de alta conversão para a agência **Croma Publicidade e Propaganda**, desenvolvida em **React 19 + TypeScript + Vite + Tailwind CSS v4**.

---

## 🚀 Como Executar Localmente

1. **Instale as dependências:**
   ```bash
   npm install
   ```

2. **Inicie o servidor de desenvolvimento:**
   ```bash
   npm run dev
   ```
   Acesse `http://localhost:3000` no seu navegador.

3. **Gerar a versão de produção (build):**
   ```bash
   npm run build
   ```
   Os arquivos finais otimizados serão gerados na pasta `dist/`.

---

## 🌐 Como Hospedar no Netlify

### Opção 1: Arrastar e Soltar (Manual Drag & Drop)
1. Execute `npm run build` na sua máquina para gerar a pasta `dist`.
2. Acesse [app.netlify.com](https://app.netlify.com).
3. Na aba **Sites**, arraste a pasta `dist` gerada para a área de upload do Netlify.
4. Seu site estará online em segundos com HTTPS gratuito!

### Opção 2: Conectar ao GitHub / GitLab
1. Crie um repositório no seu GitHub com os arquivos deste projeto.
2. No Netlify, clique em **Add new site** > **Import an existing project**.
3. Selecione o repositório. O Netlify detectará automaticamente o arquivo `netlify.toml` já configurado:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
4. Clique em **Deploy site**.

---

## 💜 Como Usar no Lovable

1. No [Lovable.dev](https://lovable.dev), crie ou importe um novo projeto Vite/React.
2. Copie as pastas `src/`, `public/`, além do `index.html`, `package.json` e `vite.config.ts`.
3. O projeto roda com React 19, TypeScript e Tailwind CSS v4 sem dependências de backend obrigatórias.

---

## 📁 Estrutura do Projeto

- `src/components/`: Componentes modulares da landing page (Navbar, Hero, BrandManifesto, ServicesSection, DifferentialsSection, PackagesSection, TestimonialsAndFaq, ContactSection, Footer, etc.).
- `src/data/cromaData.ts`: Dados de contato, serviços, pacotes e textos oficiais.
- `public/`: Imagens em alta definição e documentos PDF oficiais da marca.
- `netlify.toml` e `public/_redirects`: Configurações de rotas e publicação direta no Netlify.
