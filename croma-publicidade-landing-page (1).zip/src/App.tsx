import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { BrandManifesto } from './components/BrandManifesto';
import { ServicesSection } from './components/ServicesSection';
import { DifferentialsSection } from './components/DifferentialsSection';
import { PackagesSection } from './components/PackagesSection';
import { TestimonialsAndFaq } from './components/TestimonialsAndFaq';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { OfficialDocumentsModal } from './components/OfficialDocumentsModal';
import { PackageItem, CROMA_CONTACT } from './data/cromaData';

export default function App() {
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const [pdfModalType, setPdfModalType] = useState<'apresentacao' | 'pacotes'>('apresentacao');
  const [selectedService, setSelectedService] = useState<string>('Pacote #2 de Posts (R$ 800/mês)');

  const handleOpenPdfModal = (type: 'apresentacao' | 'pacotes') => {
    setPdfModalType(type);
    setIsPdfModalOpen(true);
  };

  const scrollToContact = (customService?: string) => {
    if (customService) {
      setSelectedService(customService);
    }
    const element = document.getElementById('contato');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectPackage = (pkg: PackageItem) => {
    const message = encodeURIComponent(`Olá equipe Croma! Tenho interesse em contratar o *${pkg.title}* (${pkg.price}/${pkg.period}). Gostaria de tirar dúvidas e dar início ao briefing do meu negócio.`);
    window.open(`https://wa.me/${CROMA_CONTACT.whatsappNumber}?text=${message}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-[#F6F3ED] text-[#10221E] flex flex-col font-sans selection:bg-[#E86438] selection:text-white">
      {/* Top Navigation */}
      <Navbar 
        onOpenContact={() => scrollToContact()} 
        onOpenPdfModal={handleOpenPdfModal} 
      />

      {/* Main Content Area */}
      <main className="flex-1">
        
        {/* 1. Hero Section */}
        <Hero 
          onOpenContact={() => scrollToContact()} 
        />

        {/* 2. Brand Manifesto & Core Philosophy */}
        <BrandManifesto 
          onOpenContact={() => scrollToContact()} 
        />

        {/* 3. Core Capabilities / Services Grid */}
        <ServicesSection 
          onSelectService={(serviceTitle) => scrollToContact(`Interesse no serviço: ${serviceTitle}`)} 
        />

        {/* 4. Differentials & Comparison */}
        <DifferentialsSection 
          onOpenContact={() => scrollToContact()} 
        />

        {/* 6. Pricing Packages Section */}
        <PackagesSection 
          onSelectPackage={handleSelectPackage} 
          onOpenPdfModal={handleOpenPdfModal} 
        />

        {/* 7. Dúvidas Frequentes (FAQ) */}
        <TestimonialsAndFaq />

        {/* 9. Conversion & Contact Section */}
        <ContactSection 
          initialService={selectedService} 
        />

      </main>

      {/* Quiet Footer */}
      <Footer 
        onOpenPdfModal={handleOpenPdfModal} 
        onOpenContact={() => scrollToContact()} 
      />

      {/* Floating WhatsApp Action */}
      <FloatingWhatsApp />

      {/* Official PDF Document Viewer Modal */}
      <OfficialDocumentsModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        initialType={pdfModalType}
      />
    </div>
  );
}
