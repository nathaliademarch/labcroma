export interface ServiceItem {
  id: string;
  category: 'social' | 'trafego' | 'branding' | 'web' | 'gastronomia' | 'copy';
  title: string;
  shortDesc: string;
  fullDesc: string;
  deliverables: string[];
  highlight?: string;
  iconName: string;
}

export interface PackageItem {
  id: string;
  number: string;
  title: string;
  badge?: string;
  price: string;
  period: string;
  description: string;
  targetAudience: string;
  staticPosts: string;
  carouselPosts: string;
  postsPerWeek: string;
  features: string[];
  recommended?: boolean;
}

export interface PortfolioCase {
  id: string;
  client: string;
  segment: string;
  tag: 'industria' | 'saude' | 'turismo' | 'gastronomia';
  headline: string;
  challenge: string;
  solution: string;
  results: string[];
  imageSrc: string;
  imageAlt: string;
  pdfPage: number;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export const CROMA_CONTACT = {
  agencyName: "Croma Publicidade e Propaganda",
  slogan: "Estratégia, Criatividade e Execução para acelerar sua marca no digital.",
  whatsappNumber: "5548992189049",
  whatsappFormatted: "(48) 99218-9049",
  email: "contato@cromapublicidade.com.br",
  instagram: "@croma.publicidade",
  instagramUrl: "https://instagram.com",
  documents: {
    apresentacaoComercial: "/assets/aistudio/Croma_-_Apresenta__o_Comercial_e3855b80.pdf",
    pacotePosts: "/assets/aistudio/Croma_-_Pacote_posts_26932d96.pdf",
    portfolio: "/assets/aistudio/PORTIFOLIO_CROMA_98e32a89.pdf"
  }
};

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "redes-sociais",
    category: "social",
    title: "Gestão de Redes Sociais",
    shortDesc: "Planejamento, criação e estratégia completa para Instagram e Facebook.",
    fullDesc: "Transformamos o feed da sua marca em um canal estratégico de autoridade e atração de clientes qualificados. Não fazemos apenas postagens: criamos ecossistemas de conteúdo.",
    deliverables: [
      "Planejamento e estratégia mensal de conteúdo",
      "Criação de linha editorial personalizada",
      "Identidade visual exclusiva para feed e stories",
      "Design de posts, capas de reels, stories e criativos",
      "Roteiros estratégicos e legendas persuasivas",
      "Relatórios mensais detalhados de desempenho"
    ],
    highlight: "Constância & Engajamento",
    iconName: "Share2"
  },
  {
    id: "trafego-pago",
    category: "trafego",
    title: "Tráfego Pago (Meta & Google Ads)",
    shortDesc: "Campanhas assertivas para colocar sua marca na frente dos clientes certos.",
    fullDesc: "Gestão profissional de anúncios orientada a retorno financeiro (ROAS). Mapeamos a jornada do cliente, criamos funis e otimizamos orçamentos para gerar leads e vendas reais.",
    deliverables: [
      "Configuração profissional de contas de anúncio e Pixel/API",
      "Segmentação estratégica por público, interesse e geolocalização",
      "Criação e teste A/B de criativos de alta conversão",
      "Otimização contínua de campanhas e orçamento",
      "Integração com objetivos reais de faturamento do cliente",
      "Painel de métricas e acompanhamento quinzenal"
    ],
    highlight: "Alta Conversão",
    iconName: "TrendingUp"
  },
  {
    id: "identidade-visual",
    category: "branding",
    title: "Identidade Visual & Branding",
    shortDesc: "Criação de marcas memoráveis que transmitem valor, autoridade e profissionalismo.",
    fullDesc: "Toda marca tem uma cor, um tom e uma presença que precisam ser explorados para brilhar. Desenvolvemos universos visuais completos que elevam a percepção de valor.",
    deliverables: [
      "Criação de logotipo completo e símbolo exclusivo",
      "Construção de paleta de cores primária e secundária",
      "Definição de tipografias e elementos visuais de apoio",
      "Manual de marca completo e diretrizes de aplicação",
      "Aplicações em papelaria (cartões, timbrados, pastas)",
      "Templates padronizados para mídias sociais"
    ],
    highlight: "Posicionamento Forte",
    iconName: "Palette"
  },
  {
    id: "landing-pages",
    category: "web",
    title: "Landing Pages de Alta Conversão",
    shortDesc: "Layouts e páginas estratégicas desenhadas exclusivamente para converter visitantes em clientes.",
    fullDesc: "Criamos páginas de vendas e captura com arquitetura de informação otimizada, copywriting persuasivo, carregamento ultrarrápido e design responsivo impecável.",
    deliverables: [
      "Estruturação de layout estratégica para páginas de vendas",
      "Design focado na jornada do usuário e gatilhos de conversão",
      "Versão 100% responsiva (mobile, tablet e desktop)",
      "Integração direta com WhatsApp, formulários e CRM",
      "Entrega pronta e homologada com rastreamento configurado"
    ],
    highlight: "Foco em Vendas",
    iconName: "Layout"
  },
  {
    id: "copywriting",
    category: "copy",
    title: "Copywriting & Redação Profissional",
    shortDesc: "Textos persuasivos que conectam, quebram objeções e estimulam a tomada de ação.",
    fullDesc: "Palavras certas geram resultados expressivos. Produzimos narrativas sob medida para encantar seu público e transformar curiosos em compradores fiéis.",
    deliverables: [
      "Textos persuasivos para redes sociais e carrosséis",
      "Roteiros para vídeos curtos (Reels, TikTok) e vídeos de vendas",
      "Textos estruturados para sites, landing pages e propostas",
      "Headlines impactantes para anúncios de Meta e Google Ads",
      "Linha de tom de voz (Tone of Voice) para a marca"
    ],
    highlight: "Persuasão Ética",
    iconName: "PenTool"
  },
  {
    id: "design-online-offline",
    category: "branding",
    title: "Design Online & Offline",
    shortDesc: "Materiais gráficos digitais e impressos com acabamento impecável.",
    fullDesc: "Sua marca precisa causar impacto em todos os pontos de contato. Da tela do smartphone ao outdoor na rodovia, garantimos coerência estética e excelência visual.",
    deliverables: [
      "Artes personalizadas para mídias sociais e campanhas",
      "Cartões de visita, panfletos, folders e catálogos",
      "Cardápios físicos e digitais de alta elegância",
      "Banners, outdoors, totens e materiais impressos em geral",
      "Layouts profissionais para feiras, eventos e stands"
    ],
    highlight: "Omnichannel",
    iconName: "Sparkles"
  },
  {
    id: "google-meu-negocio",
    category: "web",
    title: "Google Meu Negócio & SEO Local",
    shortDesc: "Destaque sua empresa nas pesquisas locais e no Google Maps quando clientes procuram por você.",
    fullDesc: "Estar bem posicionado no Google é decisivo para empresas físicas e prestadores de serviço locais. Otimizamos sua ficha para multiplicar chamadas e rotas até seu estabelecimento.",
    deliverables: [
      "Configuração e otimização completa da ficha cadastral",
      "Estratégia de crescimento e ranqueamento local",
      "Atualizações frequentes de conteúdos, produtos e fotos",
      "Gestão de avaliações e respostas estratégicas aos clientes",
      "Melhorias contínuas de posicionamento e visibilidade"
    ],
    highlight: "Clientes Próximos",
    iconName: "MapPin"
  },
  {
    id: "consultoria-gastronomia",
    category: "gastronomia",
    title: "Consultoria para Restaurantes & Delivery",
    shortDesc: "Experiência prática direta em gastronomia para alavancar seu cardápio e vendas no delivery.",
    fullDesc: "Nossa agência tem know-how profundo na cadeia de restaurantes, bares e operações de delivery. Ajudamos a aumentar seu ticket médio e lucrar mais em cada pedido.",
    deliverables: [
      "Engenharia de cardápio (Menu Engineering) visual e psicológica",
      "Precificação estratégica e margem de contribuição",
      "Promoções inteligentes para alavancar dias fracos",
      "Configuração e otimização da loja nas plataformas de delivery (iFood, etc.)",
      "Análise de fluxo da operação de ponta a ponta (E2E)",
      "Melhoria no posicionamento, categorias e combos de alto valor"
    ],
    highlight: "Especialidade Croma",
    iconName: "Utensils"
  }
];

export const PACKAGES_DATA: PackageItem[] = [
  {
    id: "pacote-1",
    number: "01",
    title: "Pacote #1",
    badge: "Início Profissional",
    price: "R$ 500",
    period: "mensal",
    description: "Ideal para quem quer começar a criar uma presença profissional no Instagram.",
    targetAudience: "Autônomos, profissionais liberais e pequenas empresas que precisam de presença digital consistente com investimento inteligente.",
    staticPosts: "4 artes estáticas",
    carouselPosts: "4 carrosséis (de até 5 artes cada)",
    postsPerWeek: "2 posts por semana",
    features: [
      "Conteúdo 100% estratégico e planejado",
      "Identidade visual alinhada à sua marca",
      "Envio organizado via Trello ou Google Drive",
      "Até 3 alterações por arte",
      "Cronograma aprovado previamente"
    ],
    recommended: false
  },
  {
    id: "pacote-2",
    number: "02",
    title: "Pacote #2",
    badge: "Mais Popular",
    price: "R$ 800",
    period: "mensal",
    description: "Mais conteúdo, mais constância e um perfil muito mais estratégico.",
    targetAudience: "Marcas em fase de expansão que buscam ampliar o engajamento, manter autoridade ativa e estreitar a conexão com seu público.",
    staticPosts: "6 artes estáticas",
    carouselPosts: "6 carrosséis (de até 5 artes cada)",
    postsPerWeek: "3 posts por semana",
    features: [
      "Estratégia editorial focada em retenção e conexão",
      "Maior frequência para algoritmo e seguidores",
      "Identidade visual refinada para cada publicação",
      "Envio organizado via Trello ou Google Drive",
      "Até 3 alterações por arte",
      "Acompanhamento e suporte humanizado"
    ],
    recommended: true
  },
  {
    id: "pacote-3",
    number: "03",
    title: "Pacote #3",
    badge: "Máxima Conversão",
    price: "R$ 1.000",
    period: "mensal",
    description: "Ideal para fortalecimento de marca e quem quer transformar o perfil em um canal de vendas.",
    targetAudience: "Empresas consolidadas que desejam dominar seu nicho, maximizar visibilidade diária e converter seguidores em receita constante.",
    staticPosts: "8 artes estáticas",
    carouselPosts: "8 carrosséis (de até 5 artes cada)",
    postsPerWeek: "4 posts por semana",
    features: [
      "Presença de alto impacto (4 postagens semanais)",
      "Carrosséis educativos aprofundados e criativos de vendas",
      "Posicionamento de líder de segmento",
      "Planejamento mensal antecipado com cronograma",
      "Envio via Trello ou Google Drive",
      "Até 3 alterações por arte",
      "Foco direto em geração de oportunidades de negócio"
    ],
    recommended: false
  }
];

export const PORTFOLIO_CASES: PortfolioCase[] = [
  {
    id: "formafix",
    client: "Formafix Argamassas e Rejuntes",
    segment: "Indústria & Construção Civil",
    tag: "industria",
    headline: "Transformando produtos técnicos em desejo e autoridade de mercado.",
    challenge: "Uma indústria de argamassas e rejuntes precisava comunicar inovação técnica e qualidade superior para dois públicos distintos: lojistas/revendedores e profissionais da obra.",
    solution: "Desenvolvimento de linguagem visual vibrante, destacando a linha de produtos (Rejunte Acrílico, Argamassa Refratária, Reboco e Contrapiso), posts sazonais institucionais e criativos de alto contraste.",
    results: [
      "Aumento significativo no engajamento de parceiros comerciais",
      "Padronização visual de embalagens e produtos no feed",
      "Criação de autoridade com a assinatura 'Vivendo a Inovação'"
    ],
    imageSrc: "/images/portfolio_page_1.png",
    imageAlt: "Cases de posts e campanhas criativas para a Formafix",
    pdfPage: 1
  },
  {
    id: "saude-vascular",
    client: "Clínica de Saúde Vascular",
    segment: "Medicina & Bem-Estar",
    tag: "saude",
    headline: "Comunicação médica acolhedora que educa, conscientiza e atrai pacientes.",
    challenge: "Desmistificar temas vasculares complexos (como trombose, varizes e climatério) de forma acessível e ética, gerando agendamentos de consultas particulares.",
    solution: "Linha editorial humanizada baseada em checklists ('O que trazer na sua consulta?'), mitos e verdades ('3 mitos sobre a trombose') e orientações práticas de saúde com estética leve e acolhedora.",
    results: [
      "Mais de 3x em compartilhamentos e salvamentos de carrosséis educativos",
      "Aumento na busca direta por agendamento de consultas via direct",
      "Consolidação de reputação médica de referência na região"
    ],
    imageSrc: "/images/portfolio_page_1.png",
    imageAlt: "Identidade e linha editorial médica para Saúde Vascular",
    pdfPage: 1
  },
  {
    id: "pommernzug",
    client: "Pommernzug - Passeios em Pomerode",
    segment: "Turismo & Entretenimento",
    tag: "turismo",
    headline: "Conectando tradição germânica, emoção e momentos inesquecíveis.",
    challenge: "Engajar turistas e moradores da cidade mais alemã do Brasil, promovendo passeios turísticos, passeios escolares e campanhas sociais como o Abril Azul.",
    solution: "Criação de criativos calorosos com a identidade visual do famoso trenzinho vermelho, posts de feedback real de passageiros, avisos operacionais claros e celebração cultural.",
    results: [
      "Picos de reservas para passeios em grupos e excursões escolares",
      "Alta taxa de retenção e comentários positivos de famílias",
      "Campanhas comemorativas de forte apelo emocional comunitário"
    ],
    imageSrc: "/images/portfolio_page_2.png",
    imageAlt: "Campanhas criativas e peças visuais para o Pommernzug em Pomerode",
    pdfPage: 2
  },
  {
    id: "restaurantes-gastronomia",
    client: "Gastronomia & Food Service",
    segment: "Restaurantes & Delivery",
    tag: "gastronomia",
    headline: "Engenharia de cardápio e criativos que despertam apetite e aumentam o ticket médio.",
    challenge: "Bares e restaurantes frequentemente sofrem com margens apertadas no delivery e baixa saída de itens com alto potencial lucrativo.",
    solution: "Consultoria especializada de cardápio, fotos irresistíveis, reformulação de combos e campanhas estratégicas de tráfego local para delivery e salão.",
    results: [
      "Aumento médio de 24% no ticket médio dos estabelecimentos",
      "Otimização nas notas e destaques dentro das plataformas de delivery",
      "Criativos de alta conversão para pedidos diretos no WhatsApp"
    ],
    imageSrc: "/images/apresentacao_page_6.png",
    imageAlt: "Consultoria gastronômica e design para restaurantes pela Croma",
    pdfPage: 6
  }
];

export const DIFFERENTIALS_DATA = [
  {
    number: "01",
    title: "Estratégia + Criatividade + Execução",
    subtitle: "Não entregamos apenas artes bonitas",
    description: "Design sem estratégia é apenas enfeite. Na Croma, cada post, cor, texto e anúncio é concebido para posicionar sua marca, gerar identificação e converter visitantes em clientes pagantes.",
    icon: "Target"
  },
  {
    number: "02",
    title: "Atendimento Personalizado & Humano",
    subtitle: "Somos parceiros, não apenas prestadores",
    description: "Você fala diretamente com quem planeja e executa suas campanhas. Nada de tickets infinitos ou robôs impessoais: nossa equipe atua como uma verdadeira extensão do seu departamento comercial.",
    icon: "Users"
  },
  {
    number: "03",
    title: "Equipe Multidisciplinar Especializada",
    subtitle: "Cada disciplina com quem realmente domina",
    description: "Seu projeto conta com profissionais especializados em cada etapa: estrategistas, designers seniores, copywriters persuasivos, gestores de tráfego pago e consultores comerciais experientes.",
    icon: "Layers"
  },
  {
    number: "04",
    title: "Pacotes Completos e Acessíveis",
    subtitle: "Flexibilidade para cada fase do seu negócio",
    description: "Acreditamos que todo negócio merece um marketing de elite. Nossos modelos de contratação variam de pacotes mensais estruturados a projetos avulsos e consultorias fechadas.",
    icon: "ShieldCheck"
  }
];

export const FAQ_DATA: FAQItem[] = [
  {
    question: "Como funciona a contratação de um pacote de posts?",
    answer: "Após escolher o pacote ideal (ou definir conosco a melhor estratégia), iniciamos com um briefing detalhado do seu negócio. Desenvolvemos o cronograma e a identidade visual das postagens. Tudo é submetido à sua aprovação antes de ir ao ar, com organização via Trello ou Google Drive.",
    category: "Pacotes"
  },
  {
    question: "Quantas alterações posso solicitar nas artes?",
    answer: "Cada arte pode ter até 3 alterações, desde que não fuja do briefing inicial e do tema aprovado no cronograma. Isso garante agilidade na entrega mantendo a excelência do design.",
    category: "Processo"
  },
  {
    question: "A Croma também faz gestão de tráfego pago (anúncios)?",
    answer: "Sim! Gerenciamos anúncios tanto no Meta Ads (Instagram e Facebook) quanto no Google Ads. Podemos combinar seu pacote de conteúdo orgânico com campanhas patrocinadas para potencializar exponencialmente suas vendas.",
    category: "Serviços"
  },
  {
    question: "Como funciona a entrega das postagens?",
    answer: "Os conteúdos finalizados (artes em alta resolução, carrosséis ordenados e legendas persuasivas com hashtags estratégicas) são entregues via Trello ou pasta exclusiva no Google Drive para fácil download e aprovação.",
    category: "Processo"
  },
  {
    question: "A Croma atende clientes de qualquer região do Brasil?",
    answer: "Sim! Atendemos marcas e empresas em todo o território nacional. Nossas reuniões, alinhamentos e entregas acontecem de forma 100% digital, com atendimento próximo via WhatsApp e videochamadas.",
    category: "Geral"
  },
  {
    question: "O que é a consultoria especializada para restaurantes?",
    answer: "É um serviço onde aplicamos nossa experiência prática no setor gastronômico para analisar a engenharia de cardápio, precificação, promoções nos aplicativos de delivery e fluxo operacional, aumentando o ticket médio e o lucro por pedido.",
    category: "Gastronomia"
  }
];
