import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { CROMA_CONTACT } from '../data/cromaData';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  const handleClick = () => {
    const message = encodeURIComponent('Olá! Gostaria de conversar com a Croma sobre marketing digital e conhecer as propostas para a minha empresa.');
    window.open(`https://wa.me/${CROMA_CONTACT.whatsappNumber}?text=${message}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-center gap-3">
      {/* Tooltip notice */}
      {showTooltip && (
        <div className="hidden sm:flex items-center gap-2 py-2 px-3.5 bg-white text-[#112C26] rounded-xl shadow-xl border border-[#D5CDBD] text-xs font-semibold animate-subtle-float">
          <span>Olá! Converse no WhatsApp</span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
            className="text-[#889E96] hover:text-[#112C26] p-0.5"
            aria-label="Fechar dica"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating CTA Button */}
      <button
        onClick={handleClick}
        className="w-14 h-14 rounded-full bg-[#25D366] hover:bg-[#20BA5A] active:scale-95 text-white flex items-center justify-center shadow-2xl transition-all cursor-pointer group"
        aria-label="Abrir WhatsApp da Croma"
      >
        <MessageCircle className="w-7 h-7 group-hover:scale-110 transition-transform" />
      </button>
    </div>
  );
};
