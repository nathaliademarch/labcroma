import React, { useState } from 'react';
import { MessageCircle, Mail, Phone, MapPin, Send, CheckCircle2, ArrowRight } from 'lucide-react';
import { CROMA_CONTACT, SERVICES_DATA } from '../data/cromaData';

interface ContactSectionProps {
  initialService?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ initialService }) => {
  const [name, setName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [service, setService] = useState(initialService || 'Pacote #2 de Posts (R$ 800/mês)');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !whatsapp.trim()) {
      setErrorMsg('Por favor, informe seu nome e número de WhatsApp.');
      return;
    }
    setErrorMsg('');
    setSubmitted(true);

    // Build prefilled WhatsApp message
    const waText = `Olá Croma Publicidade! Meu nome é ${name} da empresa ${company || 'minha empresa'}.%0A%0A*Tenho interesse em:* ${service}%0A*Email:* ${email || 'Não informado'}%0A*Mensagem:* ${message || 'Gostaria de solicitar um diagnóstico comercial e conversar sobre os pacotes.'}`;
    
    // Open in new tab if user desires
    setTimeout(() => {
      const waUrl = `https://wa.me/${CROMA_CONTACT.whatsappNumber}?text=${waText}`;
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    }, 1000);
  };

  return (
    <section id="contato" className="py-20 lg:py-28 bg-[#112C26] text-white relative overflow-hidden">
      
      {/* Background aura */}
      <div 
        className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#E86438]/10 rounded-full blur-3xl pointer-events-none -z-0"
        aria-hidden="true" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Direct Contact Info & Value */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[#E86438] uppercase">
                <span>Vamos Conversar</span>
                <span aria-hidden="true" className="text-[#88A39A]">·</span>
                <span className="text-[#88A39A] font-medium lowercase">atendimento humanizado</span>
              </div>
              <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#FAF7F2]">
                Pronto para dar cor e <span className="font-serif-brand italic font-normal text-[#E86438]">resultado</span> à sua marca?
              </h2>
              <p className="mt-4 text-base text-[#B3C7BF] leading-relaxed">
                Preencha o formulário para receber uma proposta estratégica personalizada ou fale diretamente conosco pelo WhatsApp. Respondemos rapidamente.
              </p>
            </div>

            {/* Direct Channel Cards */}
            <div className="space-y-4 text-sm">
              <a
                href={`https://wa.me/${CROMA_CONTACT.whatsappNumber}?text=Olá,%20gostaria%20de%20saber%20mais%20sobre%20os%20serviços%20da%20Croma%20Publicidade!`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded-xl bg-[#173B32] border border-[#275347] hover:border-[#E86438] transition-all group cursor-pointer"
              >
                <div className="w-12 h-12 rounded-lg bg-[#E86438] text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold text-white">WhatsApp Comercial Direto</p>
                  <p className="text-xs text-[#9BB3AA] mt-0.5">{CROMA_CONTACT.whatsappFormatted} (Atendimento imediato)</p>
                </div>
              </a>

              <div className="flex items-center gap-4 p-4 rounded-xl bg-[#173B32] border border-[#275347]">
                <div className="w-12 h-12 rounded-lg bg-[#112C26] border border-[#2B5448] text-[#FAF7F2] flex items-center justify-center shrink-0">
                  <Mail className="w-6 h-6 text-[#E86438]" />
                </div>
                <div>
                  <p className="font-semibold text-white">Email Corporativo</p>
                  <p className="text-xs text-[#9BB3AA] mt-0.5">{CROMA_CONTACT.email}</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 rounded-xl bg-[#173B32] border border-[#275347]">
                <div className="w-12 h-12 rounded-lg bg-[#112C26] border border-[#2B5448] text-[#FAF7F2] flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6 text-[#E86438]" />
                </div>
                <div>
                  <p className="font-semibold text-white">Atendimento Nacional</p>
                  <p className="text-xs text-[#9BB3AA] mt-0.5">Operação digital em todo o Brasil com reuniões online</p>
                </div>
              </div>
            </div>

            {/* Response Time Guarantee */}
            <div className="pt-4 border-t border-[#224A40] text-xs text-[#9BB3AA]">
              ✦ Horário de atendimento: Segunda a Sexta, das 08h30 às 18h30.
            </div>

          </div>

          {/* Right Column: Lead Capture Form */}
          <div className="lg:col-span-7 bg-[#FAF8F5] text-[#112C26] rounded-2xl p-6 sm:p-10 border border-[#D5CDBD] shadow-2xl">
            
            {submitted ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-[#112C26] text-white flex items-center justify-center mx-auto shadow-md">
                  <CheckCircle2 className="w-8 h-8 text-[#E86438]" />
                </div>
                <h3 className="text-2xl font-bold text-[#112C26]">Obrigado pelo seu contato!</h3>
                <p className="text-sm text-[#4E635C] max-w-md mx-auto leading-relaxed">
                  Recebemos seus dados e estamos abrindo o WhatsApp para conectar você com um dos nossos estrategistas agora mesmo.
                </p>
                <div className="pt-4">
                  <a
                    href={`https://wa.me/${CROMA_CONTACT.whatsappNumber}?text=Olá,%20acabei%20de%20enviar%20uma%20solicitação%20no%20site%20da%20Croma!`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 font-semibold text-white bg-[#E86438] hover:bg-[#D4552A] rounded-lg transition-colors shadow-sm"
                  >
                    <span>Abrir Conversa no WhatsApp</span>
                    <ArrowRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <h3 className="text-2xl font-bold text-[#112C26] tracking-tight">
                    Solicitar Diagnóstico e Orçamento
                  </h3>
                  <p className="text-xs sm:text-sm text-[#4E635C] mt-1">
                    Sem compromisso. Entraremos em contato com uma análise personalizada da sua marca.
                  </p>
                </div>

                {errorMsg && (
                  <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
                    {errorMsg}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#112C26] mb-1.5">
                      Seu Nome *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Nathalia Silva"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-[#D5CDBD] bg-white text-sm text-[#112C26] focus:outline-none focus:ring-2 focus:ring-[#112C26] focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#112C26] mb-1.5">
                      WhatsApp com DDD *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="(47) 99999-9999"
                      value={whatsapp}
                      onChange={(e) => setWhatsapp(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-[#D5CDBD] bg-white text-sm text-[#112C26] focus:outline-none focus:ring-2 focus:ring-[#112C26] focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#112C26] mb-1.5">
                      Email de Contato
                    </label>
                    <input
                      type="email"
                      placeholder="contato@empresa.com.br"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-[#D5CDBD] bg-white text-sm text-[#112C26] focus:outline-none focus:ring-2 focus:ring-[#112C26] focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#112C26] mb-1.5">
                      Nome da Empresa / @Instagram
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: Minha Empresa / @minhamarca"
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-[#D5CDBD] bg-white text-sm text-[#112C26] focus:outline-none focus:ring-2 focus:ring-[#112C26] focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#112C26] mb-1.5">
                    Serviço ou Pacote de Interesse
                  </label>
                  <select
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-[#D5CDBD] bg-white text-sm text-[#112C26] focus:outline-none focus:ring-2 focus:ring-[#112C26] focus:border-transparent cursor-pointer"
                  >
                    <option value="Pacote #1 de Posts (R$ 500/mês)">Pacote #1 de Posts — R$ 500/mês (2 posts/sem)</option>
                    <option value="Pacote #2 de Posts (R$ 800/mês)">Pacote #2 de Posts — R$ 800/mês (3 posts/sem - Mais Popular)</option>
                    <option value="Pacote #3 de Posts (R$ 1.000/mês)">Pacote #3 de Posts — R$ 1.000/mês (4 posts/sem)</option>
                    <option value="Gestão de Tráfego Pago (Meta & Google Ads)">Gestão de Tráfego Pago (Meta & Google Ads)</option>
                    <option value="Identidade Visual & Branding Completo">Identidade Visual & Branding Completo</option>
                    <option value="Landing Page de Alta Conversão">Landing Page de Alta Conversão</option>
                    <option value="Consultoria para Restaurantes & Delivery">Consultoria para Restaurantes & Delivery</option>
                    <option value="Google Meu Negócio & Presença Local">Google Meu Negócio & Presença Local</option>
                    <option value="Outro Projeto Sob Medida">Outro Projeto Sob Medida</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#112C26] mb-1.5">
                    Mensagem ou Detalhes da sua Demanda (Opcional)
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Conte resumidamente sobre seus desafios ou momento atual da empresa..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-[#D5CDBD] bg-white text-sm text-[#112C26] focus:outline-none focus:ring-2 focus:ring-[#112C26] focus:border-transparent resize-none"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-4 px-6 font-semibold text-base text-white bg-[#E86438] hover:bg-[#D4552A] active:bg-[#BF4820] rounded-lg shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer group"
                  >
                    <span>Enviar Solicitação de Diagnóstico</span>
                    <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>

                <p className="text-[11px] text-[#6E827B] text-center">
                  🔒 Seus dados são confidenciais e protegidos. Sem spam.
                </p>
              </form>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
