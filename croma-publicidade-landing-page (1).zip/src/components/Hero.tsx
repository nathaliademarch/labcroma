import React from 'react';
import { ArrowRight, CheckCircle2, MessageCircle } from 'lucide-react';
import { CROMA_CONTACT } from '../data/cromaData';

interface HeroProps {
  onOpenContact: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenContact }) => {
  return (
    <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-24">
      {/* Subtle organic background gradients inspired by Croma brand colors */}
      <div 
        className="absolute top-0 right-0 w-[550px] h-[550px] bg-gradient-to-br from-[#E86438]/10 via-[#2B584E]/10 to-transparent rounded-full blur-3xl -z-10 pointer-events-none translate-x-1/3 -translate-y-1/4" 
        aria-hidden="true"
      />
      <div 
        className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-gradient-to-tr from-[#112C26]/8 via-[#D8E5DC]/30 to-transparent rounded-full blur-3xl -z-10 pointer-events-none -translate-x-1/4 translate-y-1/4" 
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 2-Column Split: Text Argument on Left, Showcase Card on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Core Value Proposition */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Clean unboxed kicker with dot separator (Zero-Pill discipline) */}
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[#E86438] uppercase">
              <span>Agência de Soluções Digitais</span>
              <span aria-hidden="true" className="text-[#384D46]">·</span>
              <span className="text-[#384D46] font-medium lowercase">publicidade & estratégia</span>
            </div>

            {/* Display Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#112C26] leading-[1.12] text-balance">
              Aceleramos o crescimento da sua marca no <span className="font-serif-brand italic font-normal text-[#1A453C]">mercado digital</span>.
            </h1>

            {/* Subtitle directly from Apresentação Comercial */}
            <p className="text-lg sm:text-xl text-[#3A4E47] leading-relaxed max-w-2xl">
              Acreditamos que toda marca tem uma <span className="text-[#112C26] font-semibold">cor</span>, um <span className="text-[#112C26] font-semibold">tom</span> e uma <span className="text-[#112C26] font-semibold">presença</span> que precisam ser explorados para brilhar. Unimos estratégia, criatividade e execução para transformar potencial em faturamento.
            </p>

            {/* CTA Button (Removed 'Conhecer Nossos Pacotes', keeping primary 'Solicitar Diagnóstico Gratuito') */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
              <button
                onClick={onOpenContact}
                className="px-8 py-4 text-base font-semibold text-white bg-[#E86438] hover:bg-[#D4552A] active:bg-[#BF4820] rounded-lg shadow-sm hover:shadow-md transition-all text-center flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer group"
              >
                <span>Solicitar Diagnóstico Gratuito</span>
                <ArrowRight className="w-4 h-4 text-white group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                href="#servicos"
                className="px-6 py-4 text-base font-semibold text-[#112C26] bg-[#EBE4D8] hover:bg-[#E2DACB] rounded-lg transition-colors text-center flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer"
              >
                <span>Ver Nossos Serviços</span>
              </a>
            </div>

            {/* Trust points (Removed 'Planos a partir de R$ 500/mês') */}
            <div className="pt-4 border-t border-[#E3DCcf] flex flex-wrap items-center gap-6 text-xs sm:text-sm text-[#3A4E47]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#112C26] shrink-0" />
                <span>Sem contratos amarrados</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#112C26] shrink-0" />
                <span>Atendimento 100% humanizado</span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Showcase Featuring Brand Composition */}
          <div className="lg:col-span-5 relative">
            
            {/* Visual Frame */}
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Background ambient container */}
              <div className="absolute inset-0 bg-[#112C26] rounded-2xl transform rotate-1 scale-[1.02] opacity-10 blur-sm" />
              
              {/* Main Card with Deep Evergreen Frame */}
              <div className="relative bg-[#112C26] text-white rounded-2xl p-6 sm:p-7 shadow-2xl border border-[#234A41] overflow-hidden">
                
                {/* Visual Header within Card */}
                <div className="flex items-center justify-between pb-5 border-b border-[#244E44]">
                  <div>
                    <span className="text-xs uppercase tracking-wider text-[#E86438] font-bold">Soluções Visuais</span>
                    <h3 className="text-xl font-bold font-serif-brand italic tracking-tight text-[#FAF7F2]">Croma. Showcase</h3>
                  </div>
                  <span className="text-xs text-[#A1B8B1] font-mono tabular-nums">Design & Estratégia</span>
                </div>

                {/* 2-Item Balanced Showcase (No 'Pacotes de posts' and No 'Gastronomia e Delivery') */}
                <div className="mt-5 grid grid-cols-2 gap-3.5">
                  
                  {/* Item 1: Comunicação Visual & Design */}
                  <div className="group relative rounded-xl overflow-hidden bg-[#0C1F1B] border border-[#2A5248] p-2 hover:border-[#E86438] transition-all">
                    <div className="aspect-[4/3] rounded-lg overflow-hidden bg-black/40 relative">
                      <img
                        src="/images/portfolio_page_1.jpg"
                        alt="Comunicação e Design Visual"
                        className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="mt-2.5 px-1">
                      <p className="text-xs font-semibold text-white truncate">Design & Redes</p>
                      <p className="text-[11px] text-[#A1B8B1] truncate">Campanhas Estratégicas</p>
                    </div>
                  </div>

                  {/* Item 2: Identidade & Presença */}
                  <div className="group relative rounded-xl overflow-hidden bg-[#0C1F1B] border border-[#2A5248] p-2 hover:border-[#E86438] transition-all">
                    <div className="aspect-[4/3] rounded-lg overflow-hidden bg-black/40 relative">
                      <img
                        src="/images/portfolio_page_2.jpg"
                        alt="Identidade Visual e Campanhas"
                        className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="mt-2.5 px-1">
                      <p className="text-xs font-semibold text-white truncate">Identidade & Presença</p>
                      <p className="text-[11px] text-[#A1B8B1] truncate">Posicionamento de Marca</p>
                    </div>
                  </div>

                </div>

                {/* Bottom Banner within Showcase */}
                <div className="mt-5 pt-4 border-t border-[#244E44] flex items-center justify-between text-xs text-[#C7D9D3]">
                  <span className="flex items-center gap-1.5 font-medium">
                    <span className="w-2 h-2 rounded-full bg-[#E86438]" />
                    Design que conecta e converte
                  </span>
                  <span className="text-[#A1B8B1] text-[11px]">
                    Croma Publicidade
                  </span>
                </div>

              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
