import React from 'react';
import { MessageCircle, Instagram } from 'lucide-react';
import { CROMA_CONTACT } from '../data/cromaData';

interface FooterProps {
  onOpenContact?: () => void;
}

export const Footer: React.FC<FooterProps> = () => {
  return (
    <footer className="bg-[#0C1F1B] text-[#FAF7F2] border-t border-[#1C3B34]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-[#1A3831]">
          
          {/* Column 1: Brand & Slogan */}
          <div className="lg:col-span-5 space-y-4">
            <a href="#" className="flex items-center gap-1.5 text-2xl font-serif-brand font-bold italic tracking-tight text-white">
              <span>Croma</span>
              <span className="w-2 h-2 rounded-full bg-[#E86438] inline-block mb-1" />
            </a>
            
            <p className="text-xs sm:text-sm text-[#A1B8B0] leading-relaxed max-w-sm">
              {CROMA_CONTACT.agencyName}. Transformamos o seu potencial em performance e sua presença digital em um diferencial competitivo.
            </p>

            <div className="pt-2 flex items-center gap-3">
              <a
                href={CROMA_CONTACT.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-[#142D26] hover:bg-[#E86438] text-white flex items-center justify-center transition-colors cursor-pointer"
                aria-label="Instagram da Croma"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={`https://wa.me/${CROMA_CONTACT.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-[#142D26] hover:bg-[#E86438] text-white flex items-center justify-center transition-colors cursor-pointer"
                aria-label="WhatsApp da Croma"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Navigation Links */}
          <div className="lg:col-span-3 space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-[#E86438]">Navegação</p>
            <ul className="space-y-2 text-xs sm:text-sm text-[#B3C7BF]">
              <li><a href="#servicos" className="hover:text-white transition-colors">Serviços Estratégicos</a></li>
              <li><a href="#diferenciais" className="hover:text-white transition-colors">Diferenciais da Croma</a></li>
              <li><a href="#pacotes" className="hover:text-white transition-colors">Pacotes de Posts Mensais</a></li>
              <li><a href="#contato" className="hover:text-white transition-colors">Fale Conosco</a></li>
            </ul>
          </div>

          {/* Column 3: Contact Info */}
          <div className="lg:col-span-4 space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-[#E86438]">Atendimento</p>
            <div className="space-y-2 text-xs sm:text-sm text-[#B3C7BF]">
              <p>Email: <span className="text-white">{CROMA_CONTACT.email}</span></p>
              <p>WhatsApp: <span className="text-white">{CROMA_CONTACT.whatsappFormatted}</span></p>
              <p className="text-xs text-[#8BA49C] pt-1">Segunda a Sexta, das 08h30 às 18h30</p>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#7F9990]">
          <p>© {new Date().getFullYear()} {CROMA_CONTACT.agencyName}. Todos os direitos reservados.</p>
          <p className="font-mono text-[11px]">Desenvolvido com foco em alta conversão e performance digital.</p>
        </div>

      </div>
    </footer>
  );
};
