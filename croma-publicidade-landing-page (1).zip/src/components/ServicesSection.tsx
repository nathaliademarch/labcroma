import React, { useState } from 'react';
import { 
  Share2, 
  TrendingUp, 
  Palette, 
  Layout, 
  PenTool, 
  Sparkles, 
  MapPin, 
  Utensils, 
  Check, 
  ArrowRight,
  HelpCircle
} from 'lucide-react';
import { SERVICES_DATA, ServiceItem } from '../data/cromaData';

interface ServicesSectionProps {
  onSelectService: (serviceTitle: string) => void;
}

const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  Share2,
  TrendingUp,
  Palette,
  Layout,
  PenTool,
  Sparkles,
  MapPin,
  Utensils
};

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'social' | 'trafego' | 'branding' | 'web' | 'gastronomia'>('all');

  const filteredServices = SERVICES_DATA.filter((service) => {
    if (activeFilter === 'all') return true;
    return service.category === activeFilter;
  });

  return (
    <section id="servicos" className="py-20 lg:py-28 bg-[#F6F3ED] border-b border-[#E3DCcf]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[#E86438] uppercase">
            <span>Soluções Completas</span>
            <span aria-hidden="true" className="text-[#384D46]">·</span>
            <span className="text-[#384D46] font-medium lowercase">o que fazemos</span>
          </div>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#112C26]">
            Serviços estratégicos pensados para <span className="font-serif-brand italic font-normal text-[#1A453C]">gerar resultados</span>.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#3A4E47] leading-relaxed">
            Da criação da identidade até a escala com anúncios pagos e delivery: cuidamos de cada etapa da presença digital da sua empresa com profundidade técnica e excelência visual.
          </p>
        </div>

        {/* Functional Filter Tabs (Compliant with frontend-design §1.A: segmented control with active/inactive states) */}
        <div className="mt-8 flex flex-wrap items-center gap-2 p-1.5 bg-[#E8E1D3] rounded-xl max-w-fit">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeFilter === 'all'
                ? 'bg-[#112C26] text-white shadow-sm'
                : 'text-[#364942] hover:text-[#112C26] hover:bg-[#DDD5C5]'
            }`}
          >
            Todos os Serviços
          </button>
          <button
            onClick={() => setActiveFilter('social')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeFilter === 'social'
                ? 'bg-[#112C26] text-white shadow-sm'
                : 'text-[#364942] hover:text-[#112C26] hover:bg-[#DDD5C5]'
            }`}
          >
            Redes Sociais
          </button>
          <button
            onClick={() => setActiveFilter('trafego')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeFilter === 'trafego'
                ? 'bg-[#112C26] text-white shadow-sm'
                : 'text-[#364942] hover:text-[#112C26] hover:bg-[#DDD5C5]'
            }`}
          >
            Tráfego Pago
          </button>
          <button
            onClick={() => setActiveFilter('branding')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeFilter === 'branding'
                ? 'bg-[#112C26] text-white shadow-sm'
                : 'text-[#364942] hover:text-[#112C26] hover:bg-[#DDD5C5]'
            }`}
          >
            Design & Branding
          </button>
          <button
            onClick={() => setActiveFilter('web')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeFilter === 'web'
                ? 'bg-[#112C26] text-white shadow-sm'
                : 'text-[#364942] hover:text-[#112C26] hover:bg-[#DDD5C5]'
            }`}
          >
            Landing Pages & Google
          </button>
          <button
            onClick={() => setActiveFilter('gastronomia')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeFilter === 'gastronomia'
                ? 'bg-[#112C26] text-white shadow-sm'
                : 'text-[#364942] hover:text-[#112C26] hover:bg-[#DDD5C5]'
            }`}
          >
            Restaurantes & Delivery
          </button>
        </div>

        {/* Services Grid */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {filteredServices.map((service, index) => {
            const IconComponent = ICON_MAP[service.iconName] || Sparkles;
            const formattedIndex = String(index + 1).padStart(2, '0');

            return (
              <div 
                key={service.id}
                className="bg-[#FAF8F5] border border-[#E3DCcf] rounded-2xl p-6 sm:p-7 flex flex-col justify-between hover:border-[#112C26] hover:shadow-lg transition-all group"
              >
                <div>
                  
                  {/* Top card row: clean editorial numbering & category highlight */}
                  <div className="flex items-center justify-between text-xs text-[#5E736C]">
                    <span className="font-mono font-bold text-[#E86438]">{formattedIndex}.</span>
                    {service.highlight && (
                      <span className="font-medium text-[#112C26]">
                        {service.highlight}
                      </span>
                    )}
                  </div>

                  {/* Icon & Title */}
                  <div className="mt-4 flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-[#112C26] text-[#FAF7F2] flex items-center justify-center shrink-0 group-hover:bg-[#E86438] transition-colors">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-[#112C26] tracking-tight leading-snug">
                        {service.title}
                      </h3>
                      <p className="mt-1 text-xs sm:text-sm text-[#4E635C] leading-relaxed">
                        {service.shortDesc}
                      </p>
                    </div>
                  </div>

                  {/* Deliverables List directly from PDF */}
                  <div className="mt-6 pt-5 border-t border-[#ECE5D8] space-y-2.5">
                    <p className="text-xs font-semibold uppercase tracking-wider text-[#112C26]">
                      O que está incluso:
                    </p>
                    <ul className="space-y-2">
                      {service.deliverables.map((item, dIdx) => (
                        <li key={dIdx} className="flex items-start gap-2 text-xs sm:text-sm text-[#3E524C]">
                          <Check className="w-4 h-4 text-[#E86438] shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>

                {/* Bottom CTA for Service */}
                <div className="mt-6 pt-5 border-t border-[#ECE5D8]">
                  <button
                    onClick={() => onSelectService(service.title)}
                    className="w-full py-2.5 px-4 text-xs sm:text-sm font-semibold text-[#112C26] bg-[#ECE5D8] hover:bg-[#112C26] hover:text-white rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer group/btn"
                  >
                    <span>Solicitar este serviço</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#E86438] group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
