import React, { useState } from 'react';
import { Check, ArrowRight, Sparkles, FileText, Calendar, Image as ImageIcon, Layers, HelpCircle } from 'lucide-react';
import { PACKAGES_DATA, PackageItem, CROMA_CONTACT } from '../data/cromaData';

interface PackagesSectionProps {
  onSelectPackage: (pkg: PackageItem) => void;
  onOpenPdfModal: (pdfType: 'apresentacao' | 'pacotes') => void;
}

export const PackagesSection: React.FC<PackagesSectionProps> = ({ onSelectPackage, onOpenPdfModal }) => {
  return (
    <section id="pacotes" className="py-20 lg:py-28 bg-[#EDE6D9] border-b border-[#D8CEBC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-wider text-[#E86438] uppercase">
            <span>Tabela Oficial</span>
            <span aria-hidden="true" className="text-[#384D46]">·</span>
            <span className="text-[#384D46] font-medium lowercase">pacotes mensais</span>
          </div>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#112C26]">
            Conteúdo estratégico para fortalecer <br className="hidden sm:inline" />
            <span className="font-serif-brand italic font-normal text-[#1A453C]">sua marca nas redes sociais</span>.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#3A4E47] leading-relaxed">
            Sua marca presente, relevante e em constante evolução no digital. Garanta planejamento, consistência visual e mais tempo para focar nas vendas do seu negócio.
          </p>
        </div>

        {/* Why update + Why package banner (From page 2 of Pacotes PDF) */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <div className="bg-[#FAF8F5] p-6 rounded-xl border border-[#D5CDBD]">
            <h4 className="text-base font-bold text-[#112C26] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#E86438]" />
              Por que manter sua rede social atualizada?
            </h4>
            <p className="mt-2 text-xs sm:text-sm text-[#4E635C] leading-relaxed">
              Porque ela fortalece a presença da sua marca, aumenta a credibilidade imediata, gera relacionamento com o público e abre novas oportunidades de negócio diárias.
            </p>
          </div>

          <div className="bg-[#FAF8F5] p-6 rounded-xl border border-[#D5CDBD]">
            <h4 className="text-base font-bold text-[#112C26] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#E86438]" />
              E por que contratar um pacote de posts?
            </h4>
            <p className="mt-2 text-xs sm:text-sm text-[#4E635C] leading-relaxed">
              Porque você garante planejamento prévio, consistência nas publicações, um visual profissional alinhado à sua marca e tranquilidade total para liderar sua empresa.
            </p>
          </div>
        </div>

        {/* 3 Packages Cards Grid */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {PACKAGES_DATA.map((pkg) => {
            const isFeatured = pkg.recommended;

            return (
              <div
                key={pkg.id}
                className={`rounded-2xl transition-all flex flex-col justify-between relative ${
                  isFeatured
                    ? 'bg-[#112C26] text-white border-2 border-[#E86438] shadow-2xl scale-100 lg:scale-[1.03] z-10 p-7 sm:p-8'
                    : 'bg-[#FAF8F5] text-[#112C26] border border-[#D5CDBD] shadow-sm hover:border-[#112C26] p-6 sm:p-7'
                }`}
              >
                {/* Featured Badge */}
                {isFeatured && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-[#E86438] text-white text-xs font-bold uppercase tracking-wider rounded-full shadow-md whitespace-nowrap">
                    ⭐ Escolha Mais Popular
                  </div>
                )}

                <div>
                  {/* Package Top Meta */}
                  <div className="flex items-center justify-between pb-4 border-b border-black/10 dark:border-white/10">
                    <span className={`text-xs font-mono font-bold ${isFeatured ? 'text-[#E86438]' : 'text-[#826E60]'}`}>
                      Pacote {pkg.number}
                    </span>
                    <span className={`text-xs font-semibold ${isFeatured ? 'text-[#C5D9D2]' : 'text-[#5E736C]'}`}>
                      {pkg.badge}
                    </span>
                  </div>

                  {/* Title & Price with tabular numbers */}
                  <div className="mt-5">
                    <h3 className={`text-2xl font-bold tracking-tight ${isFeatured ? 'text-white' : 'text-[#112C26]'}`}>
                      {pkg.title}
                    </h3>
                    
                    <div className="mt-3 flex items-baseline gap-1.5">
                      <span className={`text-4xl font-extrabold tracking-tight font-mono tabular-nums ${isFeatured ? 'text-[#FAF7F2]' : 'text-[#112C26]'}`}>
                        {pkg.price}
                      </span>
                      <span className={`text-sm ${isFeatured ? 'text-[#9BB3AA]' : 'text-[#5E736C]'}`}>
                        /{pkg.period}
                      </span>
                    </div>

                    <p className={`mt-3 text-xs sm:text-sm leading-relaxed ${isFeatured ? 'text-[#C5D9D2]' : 'text-[#4E635C]'}`}>
                      {pkg.description}
                    </p>
                  </div>

                  {/* Quantities Breakdown from PDF */}
                  <div className={`mt-6 p-4 rounded-xl space-y-2 text-xs font-medium ${isFeatured ? 'bg-[#183B33] text-white' : 'bg-[#EDE6D9] text-[#112C26]'}`}>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <ImageIcon className="w-3.5 h-3.5 text-[#E86438]" />
                        Artes Estáticas:
                      </span>
                      <strong className="font-bold">{pkg.staticPosts}</strong>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-[#E86438]" />
                        Carrosséis:
                      </span>
                      <strong className="font-bold">{pkg.carouselPosts}</strong>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-black/10 dark:border-white/10">
                      <span className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-[#E86438]" />
                        Frequência:
                      </span>
                      <strong className="font-bold text-[#E86438]">{pkg.postsPerWeek}</strong>
                    </div>
                  </div>

                  {/* Features list */}
                  <div className="mt-6 space-y-2.5">
                    <p className={`text-xs font-semibold uppercase tracking-wider ${isFeatured ? 'text-[#E86438]' : 'text-[#112C26]'}`}>
                      Incluso neste plano:
                    </p>
                    <ul className="space-y-2">
                      {pkg.features.map((feature, fIdx) => (
                        <li key={fIdx} className="flex items-start gap-2 text-xs sm:text-sm">
                          <Check className={`w-4 h-4 shrink-0 mt-0.5 ${isFeatured ? 'text-[#E86438]' : 'text-[#112C26]'}`} />
                          <span className={isFeatured ? 'text-[#DCEAE5]' : 'text-[#3E534D]'}>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>

                {/* Card Button */}
                <div className="mt-8 pt-5 border-t border-black/10 dark:border-white/10">
                  <button
                    onClick={() => onSelectPackage(pkg)}
                    className={`w-full py-3.5 px-4 font-semibold text-sm rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm ${
                      isFeatured
                        ? 'bg-[#E86438] hover:bg-[#D4552A] text-white shadow-[#E86438]/20'
                        : 'bg-[#112C26] hover:bg-[#1D443B] text-white'
                    }`}
                  >
                    <span>Contratar {pkg.title}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

        {/* Observações & Regras de Transparência Croma (From Page 6 of Pacotes PDF) */}
        <div className="mt-16 bg-[#FAF8F5] border border-[#D5CDBD] rounded-2xl p-6 sm:p-8 max-w-4xl mx-auto">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#E86438]">
            <HelpCircle className="w-4 h-4" />
            <span>Transparência e Regras de Entrega</span>
          </div>
          <h3 className="mt-2 text-xl font-bold text-[#112C26]">
            Como funciona a operação dos Pacotes de Posts?
          </h3>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm text-[#3E534D]">
            <div className="p-3.5 bg-[#EDE6D9]/60 rounded-xl border border-[#DFD6C6]">
              <strong className="block text-[#112C26] font-semibold mb-1">📁 Envio Organizado:</strong>
              Posts enviados diretamente através do Trello ou pasta compartilhada no Google Drive.
            </div>

            <div className="p-3.5 bg-[#EDE6D9]/60 rounded-xl border border-[#DFD6C6]">
              <strong className="block text-[#112C26] font-semibold mb-1">📅 Aprovação Prévia:</strong>
              Conteúdos selecionados pelo cliente ou através de um cronograma previamente aprovado.
            </div>

            <div className="p-3.5 bg-[#EDE6D9]/60 rounded-xl border border-[#DFD6C6]">
              <strong className="block text-[#112C26] font-semibold mb-1">💳 Condição de Pagamento:</strong>
              Pagamento no ato da compra do pacote selecionado, com ativação imediata do briefing.
            </div>

            <div className="p-3.5 bg-[#EDE6D9]/60 rounded-xl border border-[#DFD6C6]">
              <strong className="block text-[#112C26] font-semibold mb-1">✏️ Alterações Inclusas:</strong>
              Artes podem ter até 3 alterações, desde que não fuja do design inicial e tema previamente aprovado.
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-[#D5CDBD] flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-xs text-[#5E736C]">
              Precisa de um pacote sob medida com mais posts ou tráfego pago integrado?
            </span>
            <button
              onClick={() => onOpenPdfModal('pacotes')}
              className="text-xs font-semibold text-[#112C26] hover:text-[#E86438] underline underline-offset-4 cursor-pointer"
            >
              Visualizar PDF dos Pacotes de Posts
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
