import React from 'react';
import { Target, Users, Layers, ShieldCheck, Check, X, ArrowRight } from 'lucide-react';
import { DIFFERENTIALS_DATA } from '../data/cromaData';

interface DifferentialsSectionProps {
  onOpenContact: () => void;
}

const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  Target,
  Users,
  Layers,
  ShieldCheck
};

export const DifferentialsSection: React.FC<DifferentialsSectionProps> = ({ onOpenContact }) => {
  return (
    <section id="diferenciais" className="py-20 lg:py-28 bg-[#EDE6D9] border-b border-[#D8CEBC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-wider text-[#E86438] uppercase">
            <span>Diferenciais Exclusivos</span>
            <span aria-hidden="true" className="text-[#384D46]">·</span>
            <span className="text-[#384D46] font-medium lowercase">por que a croma</span>
          </div>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#112C26]">
            Pilares que poucas agências <br className="hidden sm:inline" />
            <span className="font-serif-brand italic font-normal text-[#1A453C]">conseguem entregar juntas</span>.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#3A4E47] leading-relaxed">
            Eliminamos os problemas clássicos de agências convencionais: falta de retorno, artes genéricas sem foco comercial e comunicação distante.
          </p>
        </div>

        {/* 4 Pillars Grid directly from Page 7 of Apresentação Comercial */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {DIFFERENTIALS_DATA.map((diff) => {
            const IconComponent = ICON_MAP[diff.icon] || Target;

            return (
              <div 
                key={diff.number}
                className="bg-[#FAF8F5] border border-[#D5CDBD] rounded-2xl p-7 sm:p-8 flex flex-col justify-between hover:border-[#112C26] transition-all"
              >
                <div>
                  <div className="flex items-center justify-between pb-4 border-b border-[#ECE5D8]">
                    <span className="font-mono text-sm font-bold text-[#E86438]">{diff.number}.</span>
                    <span className="text-xs font-semibold text-[#5B7069] uppercase tracking-wider">{diff.subtitle}</span>
                  </div>

                  <div className="mt-5 flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-[#112C26] text-[#FAF7F2] flex items-center justify-center shrink-0">
                      <IconComponent className="w-6 h-6 text-[#E86438]" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-[#112C26] tracking-tight">
                        {diff.title}
                      </h3>
                      <p className="mt-2 text-sm sm:text-base text-[#3E534D] leading-relaxed">
                        {diff.description}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-[#ECE5D8] flex items-center gap-2 text-xs font-semibold text-[#112C26]">
                  <Check className="w-4 h-4 text-[#E86438]" />
                  <span>Compromisso garantido em contrato</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Comparison Table: Traditional vs Croma */}
        <div className="mt-16 bg-[#FAF8F5] border border-[#D5CDBD] rounded-2xl p-6 sm:p-8 shadow-sm">
          <div className="max-w-2xl">
            <h3 className="text-2xl font-bold text-[#112C26] tracking-tight">
              A diferença real no dia a dia da sua empresa
            </h3>
            <p className="text-sm text-[#4E635C] mt-1">
              Veja por que empresas de variados portes trocam agências tradicionais pela parceria estratégica da Croma.
            </p>
          </div>

          <div className="mt-6 overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse min-w-[550px]">
              <thead>
                <tr className="border-b border-[#D5CDBD] text-[#112C26]">
                  <th className="py-3 px-4 font-semibold w-1/3">Critério</th>
                  <th className="py-3 px-4 font-semibold text-[#7A6458] w-1/3">Agências Tradicionais</th>
                  <th className="py-3 px-4 font-bold text-[#112C26] bg-[#112C26]/5 rounded-t-lg w-1/3">
                    Croma Publicidade
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E7DECf] text-[#364A44]">
                <tr>
                  <td className="py-3.5 px-4 font-medium text-[#112C26]">Foco das Entregas</td>
                  <td className="py-3.5 px-4 text-[#7A6458] flex items-center gap-2">
                    <X className="w-4 h-4 text-red-500 shrink-0" />
                    <span>Apenas "encher feed" com artes bonitas</span>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-[#112C26] bg-[#112C26]/5 flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#E86438] shrink-0" />
                    <span>Estratégia + Vendas + Identidade forte</span>
                  </td>
                </tr>

                <tr>
                  <td className="py-3.5 px-4 font-medium text-[#112C26]">Comunicação & Suporte</td>
                  <td className="py-3.5 px-4 text-[#7A6458] flex items-center gap-2">
                    <X className="w-4 h-4 text-red-500 shrink-0" />
                    <span>Tickets lentos e atendentes impessoais</span>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-[#112C26] bg-[#112C26]/5 flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#E86438] shrink-0" />
                    <span>Contato direto via WhatsApp com especialistas</span>
                  </td>
                </tr>

                <tr>
                  <td className="py-3.5 px-4 font-medium text-[#112C26]">Flexibilidade Contratual</td>
                  <td className="py-3.5 px-4 text-[#7A6458] flex items-center gap-2">
                    <X className="w-4 h-4 text-red-500 shrink-0" />
                    <span>Fidelidade de 12 meses com multas pesadas</span>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-[#112C26] bg-[#112C26]/5 flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#E86438] shrink-0" />
                    <span>Pacotes mensais transparentes e acessíveis</span>
                  </td>
                </tr>

                <tr>
                  <td className="py-3.5 px-4 font-medium text-[#112C26]">Alterações nas Artes</td>
                  <td className="py-3.5 px-4 text-[#7A6458] flex items-center gap-2">
                    <X className="w-4 h-4 text-red-500 shrink-0" />
                    <span>Cobram taxas extras ou demoram semanas</span>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-[#112C26] bg-[#112C26]/5 rounded-b-lg flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#E86438] shrink-0" />
                    <span>Até 3 alterações inclusas por arte</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-[#D5CDBD]">
            <p className="text-xs sm:text-sm text-[#4E635C]">
              Pronto para transformar sua presença digital com quem realmente entende do assunto?
            </p>
            <button
              onClick={onOpenContact}
              className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#112C26] hover:bg-[#1C463C] rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap cursor-pointer"
            >
              <span>Falar com Nossa Equipe</span>
              <ArrowRight className="w-4 h-4 text-[#E86438]" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
