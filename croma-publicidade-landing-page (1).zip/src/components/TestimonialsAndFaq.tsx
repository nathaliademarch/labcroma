import React, { useState } from 'react';
import { ChevronDown, MessageSquare } from 'lucide-react';
import { FAQ_DATA, FAQItem } from '../data/cromaData';

export const TestimonialsAndFaq: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20 lg:py-28 bg-[#EDE6D9] border-b border-[#D8CEBC]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* FAQ Header */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-wider text-[#E86438] uppercase">
            <MessageSquare className="w-4 h-4" />
            <span>Dúvidas Frequentes</span>
            <span aria-hidden="true" className="text-[#384D46]">·</span>
            <span className="text-[#384D46] font-medium lowercase">processo & entregas</span>
          </div>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold tracking-tight text-[#112C26]">
            Tudo o que você precisa saber <br className="hidden sm:inline" />
            <span className="font-serif-brand italic font-normal text-[#1A453C]">sobre o nosso trabalho</span>.
          </h2>
          <p className="mt-3 text-base text-[#4E635C] max-w-2xl mx-auto leading-relaxed">
            Respostas diretas sobre nossos pacotes, metodologia de criação, formatos de entrega e aprovação de cronogramas.
          </p>
        </div>

        {/* FAQ Accordion List */}
        <div className="mt-12 space-y-3.5">
          {FAQ_DATA.map((item, fIdx) => {
            const isOpen = openIndex === fIdx;

            return (
              <div 
                key={fIdx}
                className="bg-[#FAF8F5] border border-[#D5CDBD] rounded-xl overflow-hidden transition-all shadow-sm"
              >
                <button
                  onClick={() => toggleFaq(fIdx)}
                  className="w-full py-4.5 px-6 text-left flex items-center justify-between gap-4 font-bold text-sm sm:text-base text-[#112C26] hover:bg-[#EDE6D9]/50 transition-colors cursor-pointer"
                >
                  <span>{item.question}</span>
                  <ChevronDown className={`w-5 h-5 text-[#E86438] shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
                </button>

                {isOpen && (
                  <div className="px-6 pb-5 pt-1 text-xs sm:text-sm text-[#3E534D] leading-relaxed border-t border-[#EAE3D6]">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
