import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';

interface BrandManifestoProps {
  onOpenContact: () => void;
}

export const BrandManifesto: React.FC<BrandManifestoProps> = ({ onOpenContact }) => {
  return (
    <section className="bg-[#112C26] text-[#FAF7F2] py-20 lg:py-28 relative overflow-hidden">
      {/* Decorative ambient color spots based on Croma brand palette */}
      <div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-r from-[#1E483F]/60 via-[#E86438]/20 to-[#1E483F]/60 rounded-full blur-3xl pointer-events-none -z-0" 
        aria-hidden="true"
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-8">
        
        {/* Brand Wordmark & Propósito Lead */}
        <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#E86438] font-bold">
          <span>O Propósito Croma</span>
        </div>

        {/* Big Editorial Quote */}
        <blockquote className="text-2xl sm:text-3xl lg:text-4xl font-serif-brand italic font-normal text-[#F4EFE6] leading-relaxed max-w-4xl mx-auto">
          “A Croma tem como propósito ser a parceira estratégica que acelera o crescimento das marcas no mercado digital. Acreditamos que toda marca tem uma <span className="text-[#E86438] font-semibold underline decoration-[#E86438]/40 underline-offset-8">cor</span>, um <span className="text-[#FAF7F2] font-semibold underline decoration-[#FAF7F2]/30 underline-offset-8">tom</span> e uma <span className="text-[#FAF7F2] font-semibold underline decoration-[#FAF7F2]/30 underline-offset-8">presença</span> que precisam ser explorados para brilhar.”
        </blockquote>

        {/* Narrative from page 2 of Apresentação Comercial */}
        <p className="text-base sm:text-lg text-[#B7CCC5] max-w-2xl mx-auto leading-relaxed">
          Com um time de especialistas apaixonados pelo que fazem, a Croma nasce com um compromisso claro: crescer marcas e gerar resultados concretos. Estamos aqui para transformar o seu potencial em performance e sua presença digital em um diferencial competitivo.
        </p>

        {/* Action Button */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onOpenContact}
            className="px-8 py-3.5 text-base font-semibold text-[#112C26] bg-[#FAF7F2] hover:bg-[#FFFFFF] active:bg-[#EBE4D8] rounded-lg shadow-md transition-all flex items-center gap-2 cursor-pointer group"
          >
            <span>Vamos dar cor à sua marca?</span>
            <ArrowRight className="w-4 h-4 text-[#E86438] group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

      </div>
    </section>
  );
};
