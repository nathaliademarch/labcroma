import React, { useState } from 'react';
import { MessageSquare, Menu, X, ArrowUpRight } from 'lucide-react';
import { CROMA_CONTACT } from '../data/cromaData';

interface NavbarProps {
  onOpenContact: (defaultService?: string) => void;
  onOpenPdfModal: (pdfType: 'apresentacao' | 'pacotes') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenContact, onOpenPdfModal }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-[#F6F3ED]/90 border-b border-[#E3DCcf] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Strictly compliant Top Bar Contract: 3 zones separated by gap-8 */}
        <div className="flex items-center justify-between gap-8 h-20">
          
          {/* Zone 1: Brand Wordmark (Single clean element) */}
          <a 
            href="#" 
            className="flex items-center gap-1.5 text-2xl sm:text-3xl font-serif-brand font-bold italic tracking-tight text-[#112C26] hover:opacity-90 transition-opacity whitespace-nowrap shrink-0 group"
          >
            <span>Croma</span>
            <span className="w-2 h-2 rounded-full bg-[#E86438] inline-block mb-1 group-hover:scale-125 transition-transform" />
          </a>

          {/* Zone 2: 4-5 concise single-line nav links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#384D46]">
            <a 
              href="#servicos" 
              onClick={(e) => { e.preventDefault(); handleNavClick('#servicos'); }}
              className="hover:text-[#112C26] hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0"
            >
              Serviços
            </a>
            <a 
              href="#diferenciais" 
              onClick={(e) => { e.preventDefault(); handleNavClick('#diferenciais'); }}
              className="hover:text-[#112C26] hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0"
            >
              Diferenciais
            </a>
            <a 
              href="#pacotes" 
              onClick={(e) => { e.preventDefault(); handleNavClick('#pacotes'); }}
              className="hover:text-[#112C26] hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0"
            >
              Pacotes de Posts
            </a>
            <a 
              href="#contato" 
              onClick={(e) => { e.preventDefault(); handleNavClick('#contato'); }}
              className="hover:text-[#112C26] hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0"
            >
              Contato
            </a>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="hidden md:flex items-center gap-4 shrink-0">
            <button
              onClick={() => onOpenContact()}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-[#112C26] hover:bg-[#1D443B] active:bg-[#0D221D] rounded-lg transition-all shadow-sm flex items-center gap-2 whitespace-nowrap shrink-0 group cursor-pointer"
            >
              <span>Solicitar Diagnóstico</span>
              <ArrowUpRight className="w-4 h-4 text-[#E86438] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>

          {/* Mobile hamburger toggle */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#112C26] hover:bg-[#EDE6D9] rounded-lg transition-colors"
              aria-label="Abrir menu de navegação"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#E3DCcf] bg-[#F6F3ED] px-4 pt-3 pb-6 shadow-xl space-y-3">
          <nav className="flex flex-col gap-2 pt-2 text-base font-medium text-[#2A3F38]">
            <a 
              href="#servicos" 
              onClick={(e) => { e.preventDefault(); handleNavClick('#servicos'); }}
              className="px-3 py-2 rounded-lg hover:bg-[#EDE6D9] transition-colors"
            >
              Serviços Estratégicos
            </a>
            <a 
              href="#diferenciais" 
              onClick={(e) => { e.preventDefault(); handleNavClick('#diferenciais'); }}
              className="px-3 py-2 rounded-lg hover:bg-[#EDE6D9] transition-colors"
            >
              Por que a Croma?
            </a>
            <a 
              href="#pacotes" 
              onClick={(e) => { e.preventDefault(); handleNavClick('#pacotes'); }}
              className="px-3 py-2 rounded-lg hover:bg-[#EDE6D9] transition-colors"
            >
              Pacotes de Posts (R$ 500 a R$ 1.000)
            </a>
            <a 
              href="#contato" 
              onClick={(e) => { e.preventDefault(); handleNavClick('#contato'); }}
              className="px-3 py-2 rounded-lg hover:bg-[#EDE6D9] transition-colors"
            >
              Fale Conosco
            </a>
          </nav>

          <div className="pt-3 border-t border-[#E3DCcf] flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenContact();
              }}
              className="w-full py-3 px-4 text-center font-semibold text-white bg-[#112C26] rounded-lg shadow-sm flex items-center justify-center gap-2"
            >
              <span>Solicitar Diagnóstico Gratuito</span>
              <ArrowUpRight className="w-4 h-4 text-[#E86438]" />
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenPdfModal('apresentacao');
              }}
              className="w-full py-2.5 px-4 text-center text-sm font-medium text-[#112C26] border border-[#D5CDBD] rounded-lg hover:bg-[#EDE6D9]"
            >
              Ver Apresentação Comercial (PDF)
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
