import React, { useState } from 'react';
import { X, Download, ExternalLink, FileText, ChevronLeft, ChevronRight } from 'lucide-react';
import { CROMA_CONTACT } from '../data/cromaData';

interface OfficialDocumentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'apresentacao' | 'pacotes';
}

export const OfficialDocumentsModal: React.FC<OfficialDocumentsModalProps> = ({
  isOpen,
  onClose,
  initialType = 'apresentacao'
}) => {
  const [activeDoc, setActiveDoc] = useState<'apresentacao' | 'pacotes'>(initialType);
  const [activePageIndex, setActivePageIndex] = useState<number>(1);

  if (!isOpen) return null;

  const docConfigs = {
    apresentacao: {
      title: "Apresentação Comercial & Guia da Marca",
      description: "Propósito, diferenciais, escopo completo de serviços e posicionamento da Croma Publicidade e Propaganda.",
      totalPages: 9,
      pagePrefix: "/images/apresentacao_page_",
      pdfUrl: CROMA_CONTACT.documents.apresentacaoComercial,
      fileName: "Croma_Apresentacao_Comercial.pdf"
    },
    pacotes: {
      title: "Tabela Oficial de Pacotes de Posts",
      description: "Planos mensais de conteúdo estratégico (R$ 500, R$ 800 e R$ 1.000) e diretrizes de entrega.",
      totalPages: 6,
      pagePrefix: "/images/pacotes_page_",
      pdfUrl: CROMA_CONTACT.documents.pacotePosts,
      fileName: "Croma_Pacotes_de_Posts.pdf"
    }
  };

  const currentDoc = docConfigs[activeDoc];
  const totalPages = currentDoc.totalPages;
  const clampedPage = Math.min(Math.max(activePageIndex, 1), totalPages);

  const handleDocChange = (doc: 'apresentacao' | 'pacotes') => {
    setActiveDoc(doc);
    setActivePageIndex(1);
  };

  const handlePrevPage = () => {
    setActivePageIndex((prev) => Math.max(prev - 1, 1));
  };

  const handleNextPage = () => {
    setActivePageIndex((prev) => Math.min(prev + 1, totalPages));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-6 overflow-y-auto">
      <div className="relative bg-[#FAF8F5] max-w-5xl w-full rounded-2xl overflow-hidden shadow-2xl border border-[#D5CDBD] flex flex-col max-h-[92vh]">
        
        {/* Header Bar */}
        <div className="p-4 sm:p-5 bg-[#112C26] text-white flex items-center justify-between border-b border-[#234A41]">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-[#E86438]" />
            <div>
              <h3 className="text-base sm:text-lg font-bold tracking-tight text-[#FAF7F2]">
                Central de Documentos Oficiais
              </h3>
              <p className="text-xs text-[#A8C4BB]">
                Arquivos e guias autênticos da Croma Publicidade
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg text-white/80 hover:text-white transition-colors cursor-pointer"
            aria-label="Fechar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Document Selection Tabs */}
        <div className="p-3 bg-[#EDE6D9] border-b border-[#D5CDBD] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <button
              onClick={() => handleDocChange('apresentacao')}
              className={`px-3.5 py-1.5 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeDoc === 'apresentacao'
                  ? 'bg-[#112C26] text-white shadow-sm'
                  : 'text-[#3E534D] hover:bg-[#DDD3C2]'
              }`}
            >
              Apresentação Comercial (9 págs)
            </button>
            <button
              onClick={() => handleDocChange('pacotes')}
              className={`px-3.5 py-1.5 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeDoc === 'pacotes'
                  ? 'bg-[#112C26] text-white shadow-sm'
                  : 'text-[#3E534D] hover:bg-[#DDD3C2]'
              }`}
            >
              Pacotes de Posts (6 págs)
            </button>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={currentDoc.pdfUrl}
              download={currentDoc.fileName}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-[#E86438] hover:bg-[#D4552A] rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar PDF</span>
            </a>
            <a
              href={currentDoc.pdfUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 text-xs font-semibold text-[#112C26] bg-white border border-[#D5CDBD] hover:bg-[#F6F3ED] rounded-lg transition-colors flex items-center gap-1.5"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Abrir em Nova Aba</span>
            </a>
          </div>
        </div>

        {/* Document Info Strip */}
        <div className="px-5 py-3 bg-[#FAF8F5] border-b border-[#ECE5D8] flex items-center justify-between text-xs text-[#4E635C]">
          <div>
            <strong className="text-[#112C26]">{currentDoc.title}:</strong> {currentDoc.description}
          </div>
          <div className="flex items-center gap-2 font-mono tabular-nums shrink-0 ml-4">
            <span>Página {clampedPage} de {totalPages}</span>
          </div>
        </div>

        {/* High-res Render Viewport */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#0E1F1B] flex items-center justify-center min-h-[420px]">
          <div className="relative max-w-3xl w-full flex justify-center">
            <img
              src={`${currentDoc.pagePrefix}${clampedPage}.jpg`}
              alt={`${currentDoc.title} - Página ${clampedPage}`}
              className="max-h-[60vh] w-auto rounded-lg shadow-2xl object-contain border border-white/10"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Footer Navigation Controls */}
        <div className="p-4 bg-[#FAF8F5] border-t border-[#D5CDBD] flex items-center justify-between">
          <button
            onClick={handlePrevPage}
            disabled={clampedPage <= 1}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg flex items-center gap-1.5 transition-all ${
              clampedPage <= 1
                ? 'opacity-40 cursor-not-allowed text-[#7A8F87]'
                : 'bg-[#EDE6D9] text-[#112C26] hover:bg-[#112C26] hover:text-white cursor-pointer'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Página Anterior</span>
          </button>

          {/* Quick page jump dots / counter */}
          <div className="flex items-center gap-1.5">
            {[...Array(totalPages)].map((_, idx) => (
              <button
                key={idx}
                onClick={() => setActivePageIndex(idx + 1)}
                className={`w-7 h-7 text-xs font-mono font-bold rounded-md transition-all cursor-pointer ${
                  clampedPage === idx + 1
                    ? 'bg-[#112C26] text-white shadow-sm'
                    : 'bg-[#EDE6D9] text-[#4E635C] hover:bg-[#DDD3C2]'
                }`}
              >
                {idx + 1}
              </button>
            ))}
          </div>

          <button
            onClick={handleNextPage}
            disabled={clampedPage >= totalPages}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg flex items-center gap-1.5 transition-all ${
              clampedPage >= totalPages
                ? 'opacity-40 cursor-not-allowed text-[#7A8F87]'
                : 'bg-[#EDE6D9] text-[#112C26] hover:bg-[#112C26] hover:text-white cursor-pointer'
            }`}
          >
            <span>Próxima Página</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
